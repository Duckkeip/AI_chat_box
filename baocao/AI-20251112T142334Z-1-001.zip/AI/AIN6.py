from flask import Flask, request, jsonify, send_from_directory
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB
import os
import random
import difflib

import greeting
import creator
import bye
import story
import math_logic

app = Flask(__name__)

def clean_text(text):
    return text.lower().strip()

training_sentences = [clean_text(s) for s in greeting.training_sentences
                      + story.training_sentences
                      + creator.training_sentences
                      + bye.training_sentences]
training_labels = greeting.training_labels + story.training_labels + creator.training_labels + bye.training_labels

if len(training_sentences) != len(training_labels):
    min_len = min(len(training_sentences), len(training_labels))
    training_sentences = training_sentences[:min_len]
    training_labels = training_labels[:min_len]

responses = {}
responses.update(greeting.responses)
responses.update(story.responses)
responses.update(creator.responses)
responses.update(bye.responses)

vectorizer = TfidfVectorizer()
X = vectorizer.fit_transform(training_sentences)
model = MultinomialNB()
model.fit(X, training_labels)

def log_unlearned(sentence: str):
    sentence = sentence.strip()
    if not sentence:
        return
    file_path = "unlearned.txt"
    if not os.path.exists(file_path):
        with open(file_path, "w", encoding="utf-8") as f:
            f.write("DANH SÁCH CÂU CHƯA HỌC:\n")
    with open(file_path, "r", encoding="utf-8") as f:
        lines = f.read().splitlines()
    if sentence not in lines:
        with open(file_path, "a", encoding="utf-8") as f:
            f.write(sentence + "\n")
        print(f"📝 Đã lưu câu mới vào unlearned.txt: {sentence}")

def fuzzy_match(sentence, choices, cutoff=0.8):
    matches = difflib.get_close_matches(sentence, choices, n=1, cutoff=cutoff)
    return matches[0] if matches else None

@app.route("/")
def home():
    web_dir = r"C:\Users\admin\PycharmProjects\OpenCVProject\AI\web"
    return send_from_directory(web_dir, "index.html")

@app.route("/chat", methods=["POST"])
def chat():
    data = request.get_json()
    user_input = clean_text(data.get("message", ""))

    math_result = math_logic.try_math(user_input)
    if math_result:
        return jsonify({"response": math_result})

    match = fuzzy_match(user_input, training_sentences, cutoff=0.6)
    if match:
        idx = training_sentences.index(match)
        predicted_label = training_labels[idx]
        reply = random.choice(responses[predicted_label])
    else:
        X_test = vectorizer.transform([user_input])
        probs = model.predict_proba(X_test)[0]
        max_prob = max(probs)
        predicted_label = model.classes_[probs.argmax()]

        if max_prob < 0.5:
            reply = "Mình chưa hiểu câu này, bạn có thể nói lại không?"
            log_unlearned(user_input)
        else:
            if predicted_label in responses:
                reply = random.choice(responses[predicted_label])
            else:
                reply = "Mình chưa hiểu câu này, bạn có thể nói lại không?"
                log_unlearned(user_input)

    print(f"[DEBUG] input: {user_input}, label: {predicted_label}")

    return jsonify({"response": reply})

if __name__ == "__main__":
    print("Chatbot AAIN6 đang hoạt động!")
    print("🌐 Mở trình duyệt và vào: http://127.0.0.1:5000")
    app.run(port=5000)
