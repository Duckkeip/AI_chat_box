training_sentences = [
    "Hãy kể cho tôi nghe 1 câu chuyện"
]

training_labels = [
    "s1"
]

responses = {
    "s1": ["Ngày sửa ngày xưa"]
}
